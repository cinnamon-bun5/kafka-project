package com.example.demo.controller;


import org.apache.kafka.clients.producer.KafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.services.ProducerService;


@RestController
@RequestMapping("/kafka")
public final class Controllertest {
    private final ProducerService producerService;

    public Controllertest(ProducerService producerService) {
        this.producerService = producerService;
    }

    @PostMapping(value = "/publish")
    public void sendMessageToKafkaTopic(@RequestBody String message) {
        producerService.sendMessage(message);
    }
}
